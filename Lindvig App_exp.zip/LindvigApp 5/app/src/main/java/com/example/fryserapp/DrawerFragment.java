package com.example.fryserapp;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.fryserapp.data.FreezerItem;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;

public class DrawerFragment extends Fragment {
    private RecyclerView recycler;
    private TextView emptyText;
    private FreezerAdapter adapter;
    private final List<FreezerItem> allItems = new ArrayList<>();

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_drawer, container, false);
        recycler = v.findViewById(R.id.recycler);
        emptyText = v.findViewById(R.id.emptyText);
        recycler.setLayoutManager(new LinearLayoutManager(getContext()));
        recycler.setAdapter(adapter = new FreezerAdapter(item -> showEditDeleteDialog(item)));
        loadItems();
        return v;
    }

    private void loadItems() {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<FreezerItem> items = com.example.fryserapp.App.db.freezerDao().getAll();
            synchronized (allItems) {
                allItems.clear();
                allItems.addAll(items);
            }
            if (getActivity()==null) return;
            getActivity().runOnUiThread(() -> {
                adapter.submitList(new ArrayList<>(allItems));
                emptyText.setVisibility(allItems.isEmpty()? View.VISIBLE : View.GONE);
            });
        });
    }

    public void showAddDialog() {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_item, null);
        EditText name = view.findViewById(R.id.inputName);
        EditText drawer = view.findViewById(R.id.inputDrawer);
        EditText qty = view.findViewById(R.id.inputQty);

        new AlertDialog.Builder(getContext())
                .setTitle("Opret vare")
                .setView(view)
                .setPositiveButton("Opret", (d, which) -> {
                    String n = name.getText().toString().trim();
                    int dr = safeInt(drawer.getText().toString().trim(), 1);
                    if (dr<1) dr=1; if (dr>6) dr=6;
                    String q = qty.getText().toString().trim();
                    FreezerItem item = new FreezerItem(0, n, q, System.currentTimeMillis(), null, dr);
                    Executors.newSingleThreadExecutor().execute(() -> {
                        com.example.fryserapp.App.db.freezerDao().insert(item);
                        loadItems();
                    });
                })
                .setNegativeButton("Annuller", null)
                .show();
    }

    private void showEditDeleteDialog(FreezerItem item) {
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_item, null);
        EditText name = view.findViewById(R.id.inputName);
        EditText drawer = view.findViewById(R.id.inputDrawer);
        EditText qty = view.findViewById(R.id.inputQty);
        name.setText(item.name);
        drawer.setText(String.valueOf(item.drawer));
        qty.setText(item.quantity==null?"":item.quantity);

        new AlertDialog.Builder(getContext())
                .setTitle("Rediger / Slet")
                .setView(view)
                .setPositiveButton("Gem", (d, w) -> {
                    item.name = name.getText().toString().trim();
                    int dr = safeInt(drawer.getText().toString().trim(), item.drawer);
                    if (dr<1) dr=1; if (dr>6) dr=6;
                    item.drawer = dr;
                    item.quantity = qty.getText().toString().trim();
                    Executors.newSingleThreadExecutor().execute(() -> {
                        com.example.fryserapp.App.db.freezerDao().update(item);
                    });
                    loadItems();

                })
                .setNeutralButton("Slet", (d, w) -> {
                    Executors.newSingleThreadExecutor().execute(() -> {
                        com.example.fryserapp.App.db.freezerDao().delete(item);
                        loadItems();
                    });
                })
                .setNegativeButton("Annuller", null)
                .show();
    }

    private int safeInt(String s, int def) { try { return Integer.parseInt(s); } catch (Exception e) { return def; } }
}
